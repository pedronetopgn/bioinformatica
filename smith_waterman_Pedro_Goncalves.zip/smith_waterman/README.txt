Algoritmo considera a última posição para fazer o Backtracing.
Considerando os valores de Match = 3; Mismatch = -1; Gap = -2.

Para testar o funcionamento do algoritmo, executar a seguinte linha de código no CMD na pasta em que está o arquivo smith_waterman.py e entrada.txt:

py smith_waterman.py < entrada.txt > saida.txt

Dessa forma, será gerado um arquivo "saida.txt" que contém o resultado do alinhamento, com as novas sequências e scores finais.
